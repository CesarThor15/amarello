var path = context.getVariable("proxy.pathsuffix");
var httpverb = context.getVariable("request.verb");
var cache = false;
var cacheID;
var duracionSeg;

print(path);
print(httpverb);

if (path === "/pais" && httpverb === "POST"){
    cache = true;
    
    cacheID = path;
    duracionSeg = "120";
}

context.setVariable("flow.variable.cache", cache);
context.setVariable("flow.variable.cacheID", cacheID);
context.setVariable("flow.variable.durationCache", duracionSeg);